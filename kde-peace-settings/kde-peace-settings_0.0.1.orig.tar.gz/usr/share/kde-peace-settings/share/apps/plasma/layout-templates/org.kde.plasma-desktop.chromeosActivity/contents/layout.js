
var screenrect = screenGeometry(0); // get information about your screen h w 

function chromeos(){

 
 
var activity = new Activity("folderview")
activity.name = i18n("ChromeOs Activity")



}

chromeos()

//loadTemplate("org.kde.plasma-desktop.gnome2Panel")
