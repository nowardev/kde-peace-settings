# plasma-applet-maximize-nowardev-button
Plasma 5 maximize nowardev button
