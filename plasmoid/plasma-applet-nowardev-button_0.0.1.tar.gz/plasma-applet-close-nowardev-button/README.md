# plasma-applet-nowardev-buttons
Plasma 5 kwin buttons tweak by me 
