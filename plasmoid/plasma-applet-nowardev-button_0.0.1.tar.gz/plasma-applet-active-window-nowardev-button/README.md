# plasma-applet-active-window-nowardev-button
Plasma 5 active window nowardev button
