# plasma-applet-minimize-nowardev-button
Plasma 5 minimize nowardev button
